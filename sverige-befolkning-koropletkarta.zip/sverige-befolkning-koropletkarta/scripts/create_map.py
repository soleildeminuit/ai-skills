#!/usr/bin/env python3
"""Create the exact Swedish county population choropleth training example.

This script is intentionally narrow. It uses bundled data only and reproduces a
fixed output map for educational purposes.
"""

from __future__ import annotations

import os
import sys
import subprocess
from pathlib import Path


def ensure_packages() -> None:
    """Install required packages if missing."""
    required = {
        "pandas": "pandas",
        "matplotlib": "matplotlib",
        "fiona": "fiona",
        "shapely": "shapely",
        "numpy": "numpy",
    }
    missing = []
    for module_name, package_name in required.items():
        try:
            __import__(module_name)
        except ImportError:
            missing.append(package_name)

    if missing:
        subprocess.check_call([sys.executable, "-m", "pip", "install", *missing])


ensure_packages()

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MplPolygon, Patch
from matplotlib.collections import PatchCollection
import fiona
from shapely.geometry import shape, Polygon, MultiPolygon


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "assets" / "data"
OUTPUT_DIR = ROOT / "output"
CSV_PATH = DATA_DIR / "BE0101N1.csv"
SHP_PATH = DATA_DIR / "Lan_Sweref99TM_region.shp"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def prepare_shapefile() -> Path:
    if not SHP_PATH.exists():
        raise FileNotFoundError(f"Shapefile not found: {SHP_PATH}")
    return SHP_PATH


def classify(value: float, bins: np.ndarray) -> int:
    for i in range(len(bins) - 1):
        lower = bins[i]
        upper = bins[i + 1]
        if i < len(bins) - 2:
            if lower <= value < upper:
                return i
        else:
            if lower <= value <= upper:
                return i
    return len(bins) - 2



def fmt_int(x: float | int) -> str:
    return f"{int(x):,}".replace(",", " ")



def polygon_to_patch(poly: Polygon) -> MplPolygon:
    x, y = poly.exterior.coords.xy
    return MplPolygon(list(zip(x, y)), closed=True)



def main() -> None:
    shp_path = prepare_shapefile()

    df = pd.read_csv(CSV_PATH, encoding="cp1252")
    df_2024 = df[df["år"] == 2024].copy()

    population = df_2024.groupby("region", as_index=False)["Folkmängd"].sum()
    population["LnKod"] = population["region"].str.extract(r"^(\d{2})")
    pop_lookup = dict(zip(population["LnKod"], population["Folkmängd"]))

    values = population["Folkmängd"].to_numpy(dtype=float)
    breaks = np.quantile(values, [0, 0.2, 0.4, 0.6, 0.8, 1.0])
    breaks = np.round(breaks).astype(int)

    for i in range(1, len(breaks)):
        if breaks[i] <= breaks[i - 1]:
            breaks[i] = breaks[i - 1] + 1

    patches = []
    facecolors = []
    all_x = []
    all_y = []
    label_points = []
    labels = []

    cmap = plt.get_cmap("Blues", 5)
    class_colors = [cmap(i + 1) for i in range(5)]

    with fiona.open(shp_path) as src:
        for feat in src:
            props = feat["properties"]
            lnkod = props["LnKod"]
            lnnamn = props["LnNamn"]
            pop_val = pop_lookup.get(lnkod)
            if pop_val is None:
                continue

            geom = shape(feat["geometry"])
            cls = classify(pop_val, breaks)
            color = class_colors[cls]

            if isinstance(geom, Polygon):
                parts = [geom]
                rep = geom
            elif isinstance(geom, MultiPolygon):
                parts = list(geom.geoms)
                rep = max(parts, key=lambda g: g.area)
            else:
                continue

            for part in parts:
                if part.is_empty:
                    continue
                patch = polygon_to_patch(part)
                patches.append(patch)
                facecolors.append(color)
                xy = patch.get_xy()
                all_x.extend(xy[:, 0])
                all_y.extend(xy[:, 1])

            rp = rep.representative_point()
            label_points.append((rp.x, rp.y))
            labels.append(lnnamn)

    fig = plt.figure(figsize=(8.27, 11.69), facecolor="white")
    gs = fig.add_gridspec(
        1,
        2,
        width_ratios=[4.8, 1.5],
        wspace=0.02,
        left=0.06,
        right=0.96,
        top=0.90,
        bottom=0.08,
    )

    ax_map = fig.add_subplot(gs[0, 0])
    ax_leg = fig.add_subplot(gs[0, 1])

    collection = PatchCollection(
        patches,
        facecolor=facecolors,
        edgecolor="#4a4a4a",
        linewidth=0.35,
    )
    ax_map.add_collection(collection)

    pad_x = (max(all_x) - min(all_x)) * 0.03
    pad_y = (max(all_y) - min(all_y)) * 0.03
    ax_map.set_xlim(min(all_x) - pad_x, max(all_x) + pad_x)
    ax_map.set_ylim(min(all_y) - pad_y, max(all_y) + pad_y)
    ax_map.set_aspect("equal")
    ax_map.set_xticks([])
    ax_map.set_yticks([])
    for spine in ax_map.spines.values():
        spine.set_visible(False)

    label_whitelist = {
        "Norrbottens",
        "Västerbottens",
        "Jämtlands",
        "Västernorrlands",
        "Gävleborgs",
        "Dalarnas",
        "Värmlands",
        "Uppsala",
        "Östergötlands",
        "Västra Götalands",
        "Skåne",
        "Gotlands",
    }
    for (x, y), name in zip(label_points, labels):
        if name not in label_whitelist:
            continue
        ax_map.text(x, y, name, fontsize=7.5, ha="center", va="center", color="#1f1f1f")

    fig.suptitle("Befolkning per län i Sverige, 2024", fontsize=18, y=0.955)
    fig.text(0.06, 0.925, "Tematisk karta (koropletkarta)", fontsize=11, ha="left", va="top")

    ax_leg.axis("off")

    legend_labels = []
    for i in range(len(breaks) - 1):
        lower = breaks[i]
        upper = breaks[i + 1]
        if i < len(breaks) - 2:
            label = f"{fmt_int(lower)} – {fmt_int(upper - 1)}"
        else:
            label = f"{fmt_int(lower)} – {fmt_int(upper)}"
        legend_labels.append(label)

    handles = [
        Patch(facecolor=class_colors[i], edgecolor="#4a4a4a", linewidth=0.35, label=legend_labels[i])
        for i in range(5)
    ]

    ax_leg.legend(
        handles=handles,
        title="Antal invånare",
        loc="upper left",
        frameon=True,
        framealpha=1,
        fancybox=False,
        edgecolor="#7a7a7a",
        borderpad=0.8,
        labelspacing=0.7,
        handlelength=1.5,
        handleheight=1.0,
        fontsize=10,
        title_fontsize=11,
    )

    ax_leg.text(
        0.0,
        0.68,
        "Klassning\nKvantiler, 5 klasser\n\nTolkning\nMörkare ton = större\nbefolkning",
        transform=ax_leg.transAxes,
        ha="left",
        va="top",
        fontsize=9,
        color="#333333",
    )

    fig.text(
        0.06,
        0.045,
        "Källa: SCB befolkningsdata 2024 och länsgränser i SWEREF 99 TM (EPSG:3006).",
        ha="left",
        va="bottom",
        fontsize=8.5,
        color="#333333",
    )

    png_path = OUTPUT_DIR / "optimal_koropletkarta_befolkning_lan_2024.png"
    pdf_path = OUTPUT_DIR / "optimal_koropletkarta_befolkning_lan_2024.pdf"
    plt.savefig(png_path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.savefig(pdf_path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)

    print(f"PNG: {png_path}")
    print(f"PDF: {pdf_path}")
    print(f"Klassgränser: {breaks.tolist()}")


if __name__ == "__main__":
    main()
